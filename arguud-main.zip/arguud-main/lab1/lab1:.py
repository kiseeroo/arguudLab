import math

def fun_1():
    var_1, var_2, var_3 = 0.0, 0.0, 0.0
    exp_1 = ""
    result = ""
    print("Enter an expression")
    exp_1 = input()
    result = exp_1
    print("Result:", result)

def main():
    fun_1()
    return 0

if __name__ == "__main__":
    main()

