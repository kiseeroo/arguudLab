// Generated from src/interpreter/TinyPL.g4 by ANTLR 4.12.0
// jshint ignore: start
import antlr4 from 'antlr4';

// This class defines a complete listener for a parse tree produced by TinyPLParser.
export default class TinyPLListener extends antlr4.tree.ParseTreeListener {

	// Enter a parse tree produced by TinyPLParser#program.
	enterProgram(ctx) {
	}

	// Exit a parse tree produced by TinyPLParser#program.
	exitProgram(ctx) {
	}


	// Enter a parse tree produced by TinyPLParser#statements.
	enterStatements(ctx) {
	}

	// Exit a parse tree produced by TinyPLParser#statements.
	exitStatements(ctx) {
	}


	// Enter a parse tree produced by TinyPLParser#statement.
	enterStatement(ctx) {
	}

	// Exit a parse tree produced by TinyPLParser#statement.
	exitStatement(ctx) {
	}


	// Enter a parse tree produced by TinyPLParser#variableDeclaration.
	enterVariableDeclaration(ctx) {
	}

	// Exit a parse tree produced by TinyPLParser#variableDeclaration.
	exitVariableDeclaration(ctx) {
	}


	// Enter a parse tree produced by TinyPLParser#assignment.
	enterAssignment(ctx) {
	}

	// Exit a parse tree produced by TinyPLParser#assignment.
	exitAssignment(ctx) {
	}


	// Enter a parse tree produced by TinyPLParser#functionDeclaration.
	enterFunctionDeclaration(ctx) {
	}

	// Exit a parse tree produced by TinyPLParser#functionDeclaration.
	exitFunctionDeclaration(ctx) {
	}


	// Enter a parse tree produced by TinyPLParser#call.
	enterCall(ctx) {
	}

	// Exit a parse tree produced by TinyPLParser#call.
	exitCall(ctx) {
	}



}